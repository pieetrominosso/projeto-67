const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Configuração do Banco de Dados Persistente
const db = new sqlite3.Database('./aura.db');

db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE,
        aura INTEGER DEFAULT 0,
        clicks INTEGER DEFAULT 0,
        status TEXT DEFAULT '🔥'
    )`);
    
    // Insere jogadores de demonstração se o banco estiver vazio
    db.get("SELECT COUNT(*) AS count FROM players", (err, row) => {
        if (row.count === 0) {
            db.run("INSERT INTO players (name, aura, clicks, status) VALUES ('Lenda67', 500, 500, '🔥')");
            db.run("INSERT INTO players (name, aura, clicks, status) VALUES ('MestreNeon', 450, 450, '⚡')");
            db.run("INSERT INTO players (name, aura, clicks, status) VALUES ('BetinhaPro', 400, 400, '😎')");
        }
    });
});

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Função para enviar os dados atualizados para todos
const broadcastUpdate = () => {
    db.all("SELECT * FROM players ORDER BY aura DESC", (err, rows) => {
        if (err) return console.error(err);
        
        let globalAura = rows.reduce((sum, p) => sum + p.aura, 0);
        
        io.emit('update_ranking', {
            players: rows,
            globalAura: globalAura
        });
    });
};

io.on('connection', (socket) => {
    console.log('Novo usuário conectado:', socket.id);
    broadcastUpdate(); // Envia estado atual ao conectar

    // Recebe o clique do jogador
    socket.on('farm_aura', (playerName) => {
        // Atualização ATÔMICA: protege contra cliques simultâneos
        db.run(`UPDATE players SET aura = aura + 1, clicks = clicks + 1 WHERE name = ?`, [playerName], function(err) {
            if (!err && this.changes > 0) {
                broadcastUpdate();
            }
        });
    });

    // Funções do Admin
    socket.on('admin_action', (data) => {
        if (data.action === 'add_player') {
            db.run(`INSERT INTO players (name) VALUES (?)`, [data.name], broadcastUpdate);
        } else if (data.action === 'add_aura') {
            db.run(`UPDATE players SET aura = aura + ?, clicks = clicks + ? WHERE id = ?`, [data.amount, data.amount, data.id], broadcastUpdate);
        } else if (data.action === 'reset') {
            db.run(`UPDATE players SET aura = 0, clicks = 0`, broadcastUpdate);
        }
    });
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
    console.log(`👑 Painel Admin em http://localhost:${PORT}/admin.html`);
});